//
// Created by Marko on 9.6.2021..
//

#include "marko_nikolovski_calendarapp_JNIExample.h"

JNIEXPORT jint JNICALL Java_marko_nikolovski_calendarapp_JNIExample_hashPassword
  (JNIEnv * env, jobject jobj, jint passToHash, jint hashKey) {

    unsigned int c = (unsigned int)passToHash ^ (unsigned int)hashKey;

    int rez = (int)c;
    return rez;
}

 JNIEXPORT jint JNICALL Java_marko_nikolovski_calendarapp_JNIExample_unhashPassword
   (JNIEnv * env, jobject jobj, jint hashedPass, jint unhashKey) {
     unsigned int c = (unsigned int)hashedPass ^ (unsigned int)unhashKey;

     int rez = (int)c;
     return rez;
}




