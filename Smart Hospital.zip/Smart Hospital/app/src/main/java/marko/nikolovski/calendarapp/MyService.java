package marko.nikolovski.calendarapp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class MyService extends Service {
    private Binder binder = null;
    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        if(binder == null) {
            binder = new Binder(getApplicationContext());
        }
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        binder.stop();
        return super.onUnbind(intent);
    }
}