package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private DBhelper mDB;

    Button b4;
    EditText ime;
    EditText prezime;
    EditText lozinka;
    TextView tv;
    TextView ispis;
    String tekst;

    public boolean DaLiPostoji(Korisnik[] k) {

        boolean p = false;
        if (k == null) {
            return false;
        }

        for(int i=0; i<k.length; i++) {

            if(k[i].getmUsername().equalsIgnoreCase(tekst)) {
                Toast.makeText(RegisterActivity.this, "Korisnik sa unetim podacima već postoji! ", Toast.LENGTH_LONG).show();
                p = true;
            }
        }
        return p;
    }


    public boolean isNum(String sifra) {
        if(sifra == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(sifra);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mDB = new DBhelper(this);

        ime = findViewById(R.id.edit_ime);
        prezime = findViewById(R.id.edit_prezime);
        lozinka = findViewById(R.id.edit_lozinka);
        tv = findViewById(R.id.text5);
        ispis = findViewById(R.id.text6);

        b4 = findViewById(R.id.button4);
        b4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(ime.getText().length() == 0 || prezime.getText().length() == 0)  {
                    Toast.makeText(RegisterActivity.this, "Morate pravilno popuniti polja 'Ime' i 'Prezime'! ", Toast.LENGTH_LONG).show();
                    tv.setVisibility(View.INVISIBLE);
                } else if(!isNum(lozinka.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "Lozinka mora da sadrži samo brojeve! ", Toast.LENGTH_LONG).show();
                    tv.setVisibility(View.INVISIBLE);
                } else {
                    if (ime.getText().toString().equalsIgnoreCase("admin") && prezime.getText().toString().equalsIgnoreCase("admin")) {
                        tekst = "admin";
                    } else {
                        tekst = ime.getText().toString() + "." + prezime.getText().toString();
                    }
                    tv.setVisibility(View.VISIBLE);

                    Korisnik[] korisnici = mDB.readKorisnik();
                    int duzina;

                    if (korisnici == null) {
                        duzina = 0;
                    } else {
                        duzina = korisnici.length;
                    }


                    if (DaLiPostoji(korisnici)) {
                        ispis.setText(tekst);
                        ispis.setVisibility(View.VISIBLE);
                    } else {
                        ispis.setText(tekst);
                        ispis.setVisibility(View.VISIBLE);
                        String id = String.valueOf(++duzina);

                        String pass = lozinka.getText().toString();

                        JNIExample jni = new JNIExample();
                        int sif = jni.hashPassword(Integer.parseInt(pass), 2158);
                        Log.d("oo", String.valueOf(sif));

                        mDB.insertKorisnik(new Korisnik(id, tekst, String.valueOf(sif)));
                    }

                }

            }
        });



    }
}