package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

public class UserView extends AppCompatActivity {

    private UserAdapter adapter;
    private DBhelper mDB;
    ListView mlista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_view);

        adapter = new UserAdapter(this);
        mlista = findViewById(R.id.listaPregleda);

        mlista.setAdapter(adapter);

        mDB = new DBhelper(this);


        mDB.insertReview(new Review("1", "15.04.2018.", "Očni pregled"));
        mDB.insertReview(new Review("2","22.07.2018.", "Vađenje krvi"));
        mDB.insertReview(new Review("3","09.10.2018.", "Stomatološki pregled"));
        mDB.insertReview(new Review("1","02.02.2019.", "Očni pregled"));
        mDB.insertReview(new Review("1","24.06.2019.", "Testiranje na korona virus"));
        mDB.insertReview(new Review("2","28.09.2019.", "Vađenje krvi"));
        mDB.insertReview(new Review("3","01.05.2019.", "Stomatološki pregled"));
        mDB.insertReview(new Review("2","13.06.2020.", "Testiranje na korona virus"));
        mDB.insertReview(new Review("1","24.07.2020.", "Testiranje na korona virus"));
        mDB.insertReview(new Review("2","28.08.2020.", "Vađenje krvi"));
        mDB.insertReview(new Review("3","01.02.2021.", "Stomatološki pregled"));
        mDB.insertReview(new Review("2","13.03.2021.", "Testiranje na korona virus"));
        mDB.insertReview(new Review("4","24.07.2020.", "Testiranje na korona virus"));
        mDB.insertReview(new Review("4","28.08.2020.", "Vađenje krvi"));
        mDB.insertReview(new Review("5","01.02.2021.", "Stomatološki pregled"));
        mDB.insertReview(new Review("5","13.03.2021.", "Testiranje na korona virus"));


    }
    
    public Review[] pretraga(String id) {
        Review[] reviews = mDB.readReview();
        int i=0;
        for(Review r: reviews) {
            if (r.getmID().equalsIgnoreCase(id)) {
                i++;
            }
        }
        Review[] povratna = new Review[i];
        int j=0;
        for(Review r: reviews) {
            if (r.getmID().equalsIgnoreCase(id)) {
                povratna[j] = r;
                j++;
            }
        }

        return povratna;

    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent i = getIntent();
        String str = i.getStringExtra("ID");

        adapter.update(pretraga(str));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mDB.DeleteReviewTable();
    }
}