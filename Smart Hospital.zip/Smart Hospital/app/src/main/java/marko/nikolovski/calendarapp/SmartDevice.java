package marko.nikolovski.calendarapp;


public class SmartDevice {
    private String mID;
    private String mName;
    private String mPoruka;
    private byte[] mImage;
    private boolean mSwitch;

    public SmartDevice(String id, String name, byte[] image, boolean s) {
        this.mID = id;
        this.mImage = image;
        this.mPoruka = "NEAKTIVAN";
        this.mName = name;
        this.mSwitch = s;
    }

    public String getmID() {
        return mID;
    }

    public void setmID(String mID) {
        this.mID = mID;
    }

    public String getmPoruka() {
        return mPoruka;
    }

    public void setmPoruka(String mPoruka) {
        this.mPoruka = mPoruka;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public byte[] getmImage() {
        return mImage;
    }

    public void setmImage(byte[] mImage) {
        this.mImage = mImage;
    }

    public boolean isCheck() {
        return mSwitch;
    }

    public void setmSwitch(boolean mSwitch) {
        this.mSwitch = mSwitch;
    }
}
