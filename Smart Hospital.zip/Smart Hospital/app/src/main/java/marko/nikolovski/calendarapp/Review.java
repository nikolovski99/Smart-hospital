package marko.nikolovski.calendarapp;

public class Review {
    private String mID;
    private String mText1;
    private String mText2;

    public Review(String id, String t1, String t2) {
        this.mID = id;
        this.mText1 = t1;
        this.mText2 = t2;
    }

    public String getmID() {
        return mID;
    }

    public void setmID(String mID) {
        this.mID = mID;
    }

    public String getmText1() {
        return mText1;
    }

    public String getmText2() {
        return mText2;
    }

    public void setmText1(String mText1) {
        this.mText1 = mText1;
    }

    public void setmText2(String mText2) {
        this.mText2 = mText2;
    }
}
