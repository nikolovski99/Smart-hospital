package marko.nikolovski.calendarapp;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class Binder extends IBinder.Stub {
    private Context context;
    private sendCaller mCaller;
    public static String BASE_URL = "http://192.168.0.32:8080/api";
    public static String GET_URL = BASE_URL + "/devices/";



    public Binder(Context context)
    {
        this.context=context;
    }

    @Override
    public void sendGET() throws RemoteException {
        mCaller = new sendCaller(context);
        mCaller.start();
    }

    @Override
    public void printMessage() throws RemoteException {

    }

    public void stop() {
        mCaller.stop();
    }

    private class sendCaller implements Runnable {
        private Handler mHandler = null;
        private static final long PERIOD = 10000L;
        private boolean mRun = true;
        private HttpHelper HH;
        private DBhelper mDB;
        private DeviceAdapter adapter;




        private sendCaller(Context context)
        {
            HH = new HttpHelper();
            mDB = new DBhelper(context);
            adapter = new DeviceAdapter(context);

        }



        public void start() {
            mHandler = new Handler(Looper.getMainLooper());
            mHandler.postDelayed(this, PERIOD);
        }
        public void stop() {
            mRun = false;
            mHandler.removeCallbacks(this);
        }
        @Override
        public void run() {
            if (!mRun) return;

           /* new Thread(new Runnable() {
                @Override
                public void run() {
                    try {

                        JSONArray jsonobject = HH.getJSONArrayFromURL(GET_URL); //dobili smo json objekat sada

                        Log.e("Duzina niza: ", "ovo je: " + jsonobject.length());

                        for (int i = 0; i < jsonobject.length(); i++) {
                            //for each el of json arr, take one json obj
                            JSONObject el = jsonobject.getJSONObject(i);
                            Log.d("JSON data- ", el.toString());
                            String name = el.getString("name");
                            String id = el.getString("id");
                            String state = el.getString("state");
                            boolean state_bool;
                            if (state.toUpperCase().equals("ON")) {
                                state_bool = true;
                            } else {
                                state_bool = false;
                            }

                            Log.d("1", "cao");

                        }

                    } catch (JSONException | IOException e) {
                        e.printStackTrace();
                    }
                }
        }).start();*/
            SmartDevice[] sm = mDB.readDevice();
            adapter.update(sm);

            Log.d("Binder", "Zahtev poslat");
            mHandler.postDelayed(this, PERIOD);
        }
    }
}
