package marko.nikolovski.calendarapp;

public class Korisnik {
    private String mID;
    private String mUsername;
    private String mPassword;

    public Korisnik(String id, String username, String pass) {
        this.mID = id;
        this.mUsername = username;
        this.mPassword = pass;

    }

    public String getmID() {
        return mID;
    }

    public void setmID(String mID) {
        this.mID = mID;
    }

    public String getmUsername() {
        return mUsername;
    }

    public void setmUsername(String mUsername) {
        this.mUsername = mUsername;
    }

    public String getmPassword() {
        return mPassword;
    }

    public void setmPassword(String mPassword) {
        this.mPassword = mPassword;
    }
}
