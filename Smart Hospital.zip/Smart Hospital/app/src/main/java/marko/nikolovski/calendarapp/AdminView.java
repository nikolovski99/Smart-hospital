package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AdminView extends AppCompatActivity implements View.OnClickListener {

    private DBhelper mDB;
    private DeviceAdapter adapter;
    private Button dugme;
    private HttpHelper HH;

    public static String BASE_URL = "http://192.168.0.32:8080/api";
    String POST_URL = BASE_URL + "/device/";
    String GET_URL = BASE_URL + "/devices/";

    ListView nlista;

    public byte[] Pretvaranje(int id) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), id);
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArray);
        byte[] img = byteArray.toByteArray();

        return img;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view);

        mDB = new DBhelper(this);

        nlista = findViewById(R.id.lista_uredjaja);
        adapter = new DeviceAdapter(this);
        dugme = findViewById(R.id.dugmeDODAJ);

        dugme.setOnClickListener(this);

        HH = new HttpHelper();

        mDB.DeleteDeviceTable();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONArray jsonArray = HH.getJSONArrayFromURL(GET_URL);
                    for (int i=0; i < jsonArray.length(); i++) {
                        JSONObject jo = jsonArray.getJSONObject(i);
                        String ime = jo.getString("name");
                        String id = jo.getString("id");
                        String state = jo.getString("state");

                        boolean stanje;
                        if (state.toUpperCase().equals("ON")) {
                            stanje = true;
                        } else {
                            stanje = false;
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mDB.insertUredjaj(new SmartDevice(id, ime, Pretvaranje(R.drawable.uredjaji), stanje));
                                SmartDevice[] sm = mDB.readDevice();
                                adapter.update(sm);
                            }
                        });

                    }
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }

            }
        }).start();



        nlista.setAdapter(adapter);

        nlista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView c = (TextView) view.findViewById(R.id.id_uredjaja);
                String ID = c.getText().toString();
                Log.d("1", ID);
                Intent i = new Intent(AdminView.this, DeviceActivity.class);
                i.putExtra("ID_UREDJAJA", ID);
                startActivity(i);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

        SmartDevice[] sm = mDB.readDevice();
        adapter.update(sm);

    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.dugmeDODAJ) {
            int x = adapter.getCount();
            Log.d("broj", String.valueOf(x));
            Intent i2 = new Intent(AdminView.this, AddNewDeviceActivity.class);
            i2.putExtra("DUZINA", String.valueOf(x));
            startActivity(i2);

        }
    }


}