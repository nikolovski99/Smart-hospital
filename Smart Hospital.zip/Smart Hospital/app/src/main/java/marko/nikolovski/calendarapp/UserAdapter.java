package marko.nikolovski.calendarapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class UserAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<Review> mReview;

    public UserAdapter(Context c) {
        this.mContext = c;
        mReview = new ArrayList<>();
    }

    public void update(Review[] reviews) {
        mReview.clear();
        if(reviews!=null) {
            for(Review r : reviews) {
                mReview.add(r);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mReview.size();

    }

    @Override
    public Object getItem(int position) {
        Object rv = null;
        try {
            rv = mReview.get(position);
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
        }

        return rv;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if(view == null) {
            //inflate the layout for each list row
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(
                    Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.layout_review, null);

            ViewHolder holder = new ViewHolder();
            holder.id = view.findViewById(R.id.tekstID);
            holder.datum = view.findViewById(R.id.tekst1);
            holder.naziv = view.findViewById(R.id.tekst2);
            view.setTag(holder);
        }

        //get current item to be displayed
        Review rv = (Review) getItem(position);
        //get the TextView and ImageView
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.id.setText(rv.getmID());
        holder.datum.setText(rv.getmText1());
        holder.naziv.setText(rv.getmText2());

        return view;

    }


    private class ViewHolder {
        public TextView id = null;
        public TextView datum = null;
        public TextView naziv = null;

    }

}
