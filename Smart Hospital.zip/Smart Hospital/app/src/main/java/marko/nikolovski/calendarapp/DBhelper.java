package marko.nikolovski.calendarapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBhelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "SmartHospitalKONACNA.db";
    public static final int DATABASE_VERSION = 1;

    public DBhelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+ "UREDJAJI" + "("
                + "ID" + " TEXT, "
                + "NAZIV" + " TEXT, "
                + "PORUKA" + " TEXT, "
                + "SLIKA" + " BLOB, "
                + "STANJE" + " INTEGER); ");

        db.execSQL("CREATE TABLE "+ "KORISNICI" + "("
                + "ID" + " TEXT, "
                + "USERNAME" + " TEXT, "
                + "PASSWORD" + " TEXT); ");

        db.execSQL("CREATE TABLE "+ "PREGLEDI" + "("
                + "ID" + " TEXT, "
                + "DATUM" + " TEXT, "
                + "OPIS" + " TEXT); ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertUredjaj(SmartDevice sm) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ID", sm.getmID());
        values.put("NAZIV", sm.getmName());
        values.put("PORUKA", sm.getmPoruka());
        values.put("SLIKA", sm.getmImage());
        int stanje;

        if(sm.isCheck()) {
            stanje = 1;
        } else {
            stanje = 0;
        }

        values.put("STANJE", stanje);

        db.insert("UREDJAJI", null, values);

        close();
    }

    public void insertKorisnik(Korisnik k) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ID", k.getmID());
        values.put("USERNAME", k.getmUsername());
        values.put("PASSWORD", k.getmPassword());

        db.insert("KORISNICI", null, values);

        close();
    }


    public void insertReview(Review r) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ID", r.getmID());
        values.put("DATUM", r.getmText1());
        values.put("OPIS", r.getmText2());

        db.insert("PREGLEDI", null, values);

        close();
    }

    public void DeleteReviewTable() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("PREGLEDI", null, null);
    }

    public void DeleteDeviceTable() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("UREDJAJI", null, null);
    }

    public void DeleteUserTable() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("KORISNICI", null, null);
    }

    public Korisnik[] readKorisnik() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("KORISNICI", null, null, null, null, null, null);
        if(cursor.getCount() <= 0) {
            return null;
        }
        Korisnik[] k = new Korisnik[cursor.getCount()];
        int i=0;
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            k[i++] =  createKorisnik(cursor);
        }

        close();
        return k;
    }

    public SmartDevice[] readDevice() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("UREDJAJI", null, null, null, null, null, null);
        if(cursor.getCount() <= 0) {
            return null;
        }
        SmartDevice[] sm = new SmartDevice[cursor.getCount()];
        int i=0;
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            sm[i++] =  createDevice(cursor);
        }

        close();
        return sm;
    }

    public Review[] readReview() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("PREGLEDI", null, null, null, null, null, null);
        if(cursor.getCount() <= 0) {
            return null;
        }
        Review[] reviews = new Review[cursor.getCount()];
        int i=0;
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            reviews[i++] =  createReview(cursor);
        }

        close();
        return reviews;
    }

    private Korisnik createKorisnik(Cursor cursor) {
        String id = cursor.getString(cursor.getColumnIndex("ID"));
        String username = cursor.getString(cursor.getColumnIndex("USERNAME"));
        String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));


        return new Korisnik(id, username, password);
    }

    private SmartDevice createDevice(Cursor cursor) {
        String id = cursor.getString(cursor.getColumnIndex("ID"));
        String naziv = cursor.getString(cursor.getColumnIndex("NAZIV"));
        String poruka = cursor.getString(cursor.getColumnIndex("PORUKA"));
        byte[] slika = cursor.getBlob(cursor.getColumnIndex("SLIKA"));
        int stanje = cursor.getInt(cursor.getColumnIndex("STANJE"));
        boolean s;
        if (stanje == 0) {
            s = false;
        } else {
            s = true;
        }


        return new SmartDevice(id, naziv, slika, s);
    }

    private Review createReview(Cursor cursor) {
        String id = cursor.getString(cursor.getColumnIndex("ID"));
        String datum = cursor.getString(cursor.getColumnIndex("DATUM"));
        String opis = cursor.getString(cursor.getColumnIndex("OPIS"));


        return new Review(id, datum, opis);
    }

}
