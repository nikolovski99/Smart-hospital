package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class DeviceActivity extends AppCompatActivity {

    private HttpHelper HH;
    private TextView tekst_ime;
    private TextView tekst_id;
    private TextView tekst_tip;
    private TextView tekst_stanje;

    public static String BASE_URL = "http://192.168.0.32:8080/api";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);

        Intent i = getIntent();
        String str = i.getStringExtra("ID_UREDJAJA");

        tekst_ime = findViewById(R.id.ucitanoIME);
        tekst_id = findViewById(R.id.ucitaniID);
        tekst_tip = findViewById(R.id.ucitaniTIP);
        tekst_stanje = findViewById(R.id.ucitanSTANJE);

        HH = new HttpHelper();

        String GET_URL = BASE_URL + "/device/" + str;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject jo = HH.getJSONObjectFromURL(GET_URL);
                    String ime = jo.getString("name");
                    String id = jo.getString("id");
                    String state = jo.getString("state");
                    String tip  = jo.getString("type");

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tekst_id.setText(id);
                            tekst_ime.setText(ime);
                            tekst_stanje.setText(state);
                            tekst_tip.setText(tip);

                        }
                    });

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }

            }
        }).start();


    }
}