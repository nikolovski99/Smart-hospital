package marko.nikolovski.calendarapp;

public class JNIExample {
    static {
        System.loadLibrary("MyLibrary");
    }

    public native int hashPassword(int passToHash, int hashKey);
    public native int unhashPassword(int hashedPass, int unhashKey);
}
