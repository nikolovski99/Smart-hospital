package marko.nikolovski.calendarapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class DeviceAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<SmartDevice> mDevice;
    private HttpHelper HH;

    public static String BASE_URL = "http://192.168.0.32:8080/api";
    String POST_URL = BASE_URL + "/device/";
    String GET_URL = BASE_URL + "/devices/";

    public DeviceAdapter(Context c) {
        this.mContext = c;
        mDevice = new ArrayList<>();
    }

    public void update(SmartDevice[] sm) {
        mDevice.clear();
        if(sm!=null) {
            for(SmartDevice s : sm) {
                mDevice.add(s);
            }
        }
        notifyDataSetChanged();
    }

    public void removeDevice(SmartDevice device) {
        mDevice.remove(device);
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return mDevice.size();

    }

    @Override
    public Object getItem(int position) {
        Object rv = null;
        try {
            rv = mDevice.get(position);
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
        }

        return rv;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if(view == null) {
            //inflate the layout for each list row
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(
                    Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.layout_device, null);

            ViewHolder holder = new ViewHolder();
            holder.id = view.findViewById(R.id.id_uredjaja);
            holder.image = view.findViewById(R.id.slika_uredjaja);
            holder.mess = view.findViewById(R.id.poruka);
            holder.name = view.findViewById(R.id.ime_uredjaja);
            holder.sw = view.findViewById(R.id.dugme);
            view.setTag(holder);

        }

        //get current item to be displayed
        SmartDevice t = (SmartDevice) getItem(position);
        //get the TextView and ImageView
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.id.setText(t.getmID());
        holder.name.setText(t.getmName());

        ByteArrayInputStream is = new ByteArrayInputStream(t.getmImage());
        Bitmap bitmap = BitmapFactory.decodeStream(is);

        holder.image.setImageBitmap(bitmap);
        holder.sw.setChecked(t.isCheck());

       /* holder.sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String id_uredjaja = t.getmID();
                HH = new HttpHelper();
                if(isChecked) {

                    holder.mess.setVisibility(View.INVISIBLE);
                    holder.sw.setChecked(isChecked);
                    t.setmSwitch(isChecked);
                    Log.d("Checked? : ", String.valueOf(isChecked));

                    holder.sw.setTag(position);
                } else {
                    holder.mess.setVisibility(View.VISIBLE);

                    t.setmSwitch(isChecked);
                    Log.d("Checked? : ", String.valueOf(isChecked));
                    holder.sw.setTag(position);
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String state = null;
                            if(isChecked){
                                state = "on";
                            } else {
                                state = "off";
                            }
                            String url = POST_URL + String.valueOf(id_uredjaja) + "/" + state ;
                            Log.d("Zahtev POST_STATE: ", url);
                            JSONObject json = new JSONObject();
                            try{
                                json.put("message", "10");
                                json.put("code",  "10");

                            } catch (JSONException e) {
                                //TO DO obraditi izuzetak
                                e.printStackTrace();
                            }

                            boolean response = HH.postJSONObjectFromURL(POST_URL, json);

                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

            }
        });*/


       holder.sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String id_uredjaja = t.getmID();
                HH = new HttpHelper();

                if(isChecked) {
                    Log.d("1","Upaljen");
                    holder.name.setVisibility(View.VISIBLE);
                    holder.mess.setVisibility(View.GONE);

                } else {
                    Log.d("0","Ugasen");
                    holder.name.setVisibility(View.GONE);
                    holder.mess.setVisibility(View.VISIBLE);
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String state = null;
                            if(isChecked){
                                state = "on";
                            } else {
                                state = "off";
                            }
                            String url = POST_URL + String.valueOf(id_uredjaja) + "/" + state ;
                            Log.d("Zahtev POST_STATE: ", url);
                            JSONObject json = new JSONObject();
                            try{
                                json.put("message", "10");
                                json.put("code",  "10");

                            } catch (JSONException e) {
                                //TO DO obraditi izuzetak
                                e.printStackTrace();
                            }

                            json = HH.POSTJSONObjectFromURL(url);

                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });

        return view;
    }

    private class ViewHolder {
        public TextView id = null;
        public TextView name = null;
        public TextView mess = null;
        public ImageView image = null;
        public Switch sw = null;

    }
}
