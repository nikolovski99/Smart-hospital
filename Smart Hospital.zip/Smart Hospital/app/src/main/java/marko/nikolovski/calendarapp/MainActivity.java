package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, ServiceConnection {

    private DBhelper mDB;
    private int ID;
    private HttpHelper HH;
    private marko.nikolovski.calendarapp.IBinder mService = null;

    public static String BASE_URL = "http://192.168.0.32:8080/api";

    public boolean Provera(Korisnik[] k, String username, String password) {
        boolean p = false;
        int j;
        if(k == null) {
            return false;
        }

        JNIExample jni = new JNIExample();

        for(j=0; j<k.length; j++) {

            int rez = jni.unhashPassword(Integer.parseInt(k[j].getmPassword()),2158);
            String sifra = String.valueOf(rez);

            if (k[j].getmUsername().equalsIgnoreCase(username) && sifra.equalsIgnoreCase(password)) {
                p = true;
                setID(++j);
                break;
            }
        }


        return p;
    }

    public byte[] Pretvaranje(int id) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), id);
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArray);
        byte[] img = byteArray.toByteArray();

        return img;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    Button b1;
    Button b2;
    Button b3;
    EditText et1;
    EditText et2;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button1);
        b1.setOnClickListener(this);
        b2 = findViewById(R.id.button2);
        b2.setOnClickListener(this);
        b3 = findViewById(R.id.button3);
        b3.setOnClickListener(this);

        et1 = findViewById(R.id.ET1);
        et2 = findViewById(R.id.ET2);

        mDB = new DBhelper(this);
        HH = new HttpHelper();

        String POST_URL = BASE_URL + "/device/";
        String GET_URL = BASE_URL + "/devices/";

        Intent iB = new Intent(this, MyService.class);
        if(!bindService(iB,(ServiceConnection) this, Context.BIND_AUTO_CREATE)) {
            Log.d("Main", "bind failed");
        } else {
            Log.d("Main", "bind succes");
        }

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.button1) {
            Intent i = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(i);
        } else if (v.getId() == R.id.button2) {
            b3.setVisibility(View.VISIBLE);
            et1.setVisibility(View.VISIBLE);
            et2.setVisibility(View.VISIBLE);
        } else if (v.getId() == R.id.button3) {
            if(et1.getText().length() != 0 && et2.getText().length() != 0) {

                Korisnik[] kor = mDB.readKorisnik();
                String username = et1.getText().toString();
                String password = et2.getText().toString();
                if (Provera(kor, username, password)) {

                    if(et1.getText().toString().equalsIgnoreCase("admin")) {
                        i = new Intent(MainActivity.this, AdminView.class);
                        startActivity(i);
                    } else {
                        Log.d("id", String.valueOf(getID()));
                        i = new Intent(MainActivity.this, UserView.class);
                        i.putExtra("ID", String.valueOf(getID()));
                        startActivity(i);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Pogrešno Korisničko ime ili loznika! ", Toast.LENGTH_LONG).show();

                }
            } else {
                Toast.makeText(MainActivity.this, "Morate pravilno popuniti polja 'Username' i 'Password'! ", Toast.LENGTH_LONG).show();
            }
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mService != null) {
        unbindService(this);
        Log.d("Main", "unbind");
        mService = null;

        } else {
            Log.d("Main", "vec je null");
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        mService = marko.nikolovski.calendarapp.IBinder.Stub.asInterface(service);
        try {
            mService.sendGET();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        mService = null;
    }
}