package marko.nikolovski.calendarapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AddNewDeviceActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText ime_uredjaja;
    private EditText tip_uredjaja;
    private Button dugme_dodaj;
    private HttpHelper HH;
    private DBhelper mDB;


    public static String BASE_URL = "http://192.168.0.32:8080/api";
    String POST_URL = BASE_URL + "/device/";
    String GET_URL = BASE_URL + "/devices/";
    String str;

    public byte[] Pretvaranje(int id) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), id);
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArray);
        byte[] img = byteArray.toByteArray();

        return img;
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "student channel";
            String description = "channel for student";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("lemubitA", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_device);

        ime_uredjaja = findViewById(R.id.ime_novi);
        tip_uredjaja = findViewById(R.id.tip_novi);
        dugme_dodaj = findViewById(R.id.dugme_sacuvaj_novi);

        dugme_dodaj.setOnClickListener(this);

        HH = new HttpHelper();
        mDB = new DBhelper(this);




    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.dugme_sacuvaj_novi) {
            if (ime_uredjaja.getText().length() <= 0 && tip_uredjaja.getText().length() <= 0) {
                Toast.makeText(getApplicationContext(), "Niste uneli potrebne podatke!", Toast.LENGTH_LONG).show();
            } else {
                String ime = ime_uredjaja.getText().toString();
                String tip = tip_uredjaja.getText().toString();

                JNIExample jniEX = new JNIExample();
                int y = jniEX.unhashPassword(3,jniEX.hashPassword(2,9));

                int x = mDB.readDevice().length;
                Log.d("duzinaJNI", String.valueOf(y));
                str = String.valueOf(x);


                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject json = new JSONObject();

                        try {
                            json.put("name", ime);
                            json.put("id",  str);
                            json.put("state", "on");
                            json.put("type", tip);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        try {
                            mDB.insertUredjaj(new SmartDevice(str, ime, Pretvaranje(R.drawable.uredjaji), true));
                            boolean response = HH.postJSONObjectFromURL(POST_URL, json);

                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }).start();

                addNotification(ime);

            }

        }
    }
    private void addNotification(String ime) {
        Intent intent = new Intent(this,AddNewDeviceActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this,0,intent,0);

        String id = "channel_001";
        String name = "name";
        NotificationManager notificationManager = (NotificationManager)
                this.getSystemService(NOTIFICATION_SERVICE);

        Notification notification = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(mChannel);
            notification = new Notification.Builder(this)
                    .setChannelId(id)
                    .setContentTitle("Notification")
                    .setContentText(ime + " je uspešno dodat u bazu podataka.")
                    .setContentIntent(pi)
                    .setSmallIcon(R.drawable.hospital).build();
        } else {
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setContentTitle("Notification")
                    .setContentText(ime + " je uspešno dodat u bazu podataka.")
                    .setSmallIcon(R.drawable.hospital)
                    .setOngoing(true)
                    .setContentIntent(pi)
                    .setChannelId(id);

            notification = notificationBuilder.build();
        }

        notificationManager.notify(1,notification);
    }



}